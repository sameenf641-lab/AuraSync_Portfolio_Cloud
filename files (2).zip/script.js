/* ==========================================================================
   AuraSync Portfolio Cloud — Prank Simulation Logic
   100% client-side. No storage access, no network calls, no real data.
   Every "device" and "media" value shown below is randomly generated.
   ========================================================================== */

(() => {
  'use strict';

  /* ------------------------------------------------------------------ *
   * DOM references
   * ------------------------------------------------------------------ */
  const els = {
    phase1: document.getElementById('phase-1'),
    phase2: document.getElementById('phase-2'),
    phase3: document.getElementById('phase-3'),
    phaseFinal: document.getElementById('phase-final'),

    grantBtn: document.getElementById('grant-btn'),
    cancelBtn: document.getElementById('cancel-btn'),
    replayBtn: document.getElementById('replay-btn'),

    targetDevice: document.getElementById('target-device'),
    logList: document.getElementById('log-list'),
    spinner: document.getElementById('p2-spinner'),

    statPhotos: document.getElementById('stat-photos'),
    statVideos: document.getElementById('stat-videos'),
    statStorage: document.getElementById('stat-storage'),

    progressFill: document.getElementById('progress-fill'),
    progressPercent: document.getElementById('progress-percent'),
    filenameCurrent: document.getElementById('filename-current'),

    counterPhotos: document.getElementById('counter-photos'),
    counterVideos: document.getElementById('counter-videos'),
    counterSize: document.getElementById('counter-size'),
    counterRate: document.getElementById('counter-rate'),

    modal: document.getElementById('interrupt-modal'),
    countdown: document.getElementById('countdown'),
    countdownFill: document.getElementById('countdown-fill'),
  };

  /* ------------------------------------------------------------------ *
   * Small utilities
   * ------------------------------------------------------------------ */
  const rand = (min, max) => Math.random() * (max - min) + min;
  const randInt = (min, max) => Math.floor(rand(min, max + 1));
  const pick = (arr) => arr[randInt(0, arr.length - 1)];
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function vibrate(pattern) {
    if ('vibrate' in navigator) {
      try { navigator.vibrate(pattern); } catch (_) { /* ignore */ }
    }
  }

  /* ------------------------------------------------------------------ *
   * Phase switching — pure CSS class toggling, no data side effects
   * ------------------------------------------------------------------ */
  function showPhase(el) {
    [els.phase1, els.phase2, els.phase3, els.phaseFinal].forEach((p) => {
      if (p === el) {
        p.classList.add('phase-active');
        p.setAttribute('aria-hidden', 'false');
      } else {
        p.classList.remove('phase-active');
        p.setAttribute('aria-hidden', 'true');
      }
    });
  }

  /* ------------------------------------------------------------------ *
   * Device label — browser APIs only, never storage/photos/files.
   * Falls back gracefully across browsers.
   * ------------------------------------------------------------------ */
  function detectDeviceLabel() {
    const ua = navigator.userAgent || '';
    let deviceName = 'Unknown Device';

    if (/iPhone/i.test(ua)) deviceName = 'iPhone';
    else if (/iPad/i.test(ua)) deviceName = 'iPad';
    else if (/Android/i.test(ua)) {
      const match = ua.match(/Android[^;]*;\s*([^)]+)\)/i);
      deviceName = match && match[1] ? match[1].split('Build')[0].trim() : 'Android Device';
    } else if (/Macintosh/i.test(ua)) deviceName = 'Mac';
    else if (/Windows/i.test(ua)) deviceName = 'Windows PC';
    else if (navigator.platform) deviceName = navigator.platform;

    let browser = 'Browser';
    if (/Edg\//i.test(ua)) browser = 'Edge';
    else if (/Chrome\//i.test(ua) && !/Chromium/i.test(ua)) browser = 'Chrome';
    else if (/CriOS/i.test(ua)) browser = 'Chrome iOS';
    else if (/Firefox\//i.test(ua)) browser = 'Firefox';
    else if (/Safari\//i.test(ua) && /Version\//i.test(ua)) browser = 'Safari';

    return `${deviceName} · ${browser}`;
  }

  /* ------------------------------------------------------------------ *
   * PHASE 1 → PHASE 2 transition
   * ------------------------------------------------------------------ */
  async function tryEnterFullscreen() {
    const root = document.documentElement;
    try {
      if (root.requestFullscreen) await root.requestFullscreen();
      else if (root.webkitRequestFullscreen) await root.webkitRequestFullscreen();
    } catch (_) {
      /* Fullscreen may be denied or unsupported — simulation continues regardless. */
    }
  }

  els.grantBtn.addEventListener('click', async () => {
    vibrate(12);
    els.grantBtn.disabled = true;
    await tryEnterFullscreen();
    els.targetDevice.textContent = detectDeviceLabel();

    els.phase1.classList.add('phase-exiting');
    await wait(350);
    showPhase(els.phase2);
    runPhase2();
  });

  /* ------------------------------------------------------------------ *
   * PHASE 2 — terminal log sequence + fake stat reveal
   * ------------------------------------------------------------------ */
  const PHASE2_LOGS = [
    { tag: '[SYSTEM]', text: 'Device Authentication Successful...', done: true },
    { tag: '[SECURITY]', text: 'Secure Tunnel Established...', done: true },
    { tag: '[STORAGE]', text: 'Scanning Local Media Library...', done: false },
    { tag: '[INDEXER]', text: 'Building Asset Database...', done: false },
  ];

  function appendLogLine({ tag, text, done }) {
    const line = document.createElement('div');
    line.className = 'log-line' + (done ? ' done' : '');
    line.innerHTML = `<span class="tag">${tag}</span><span>${text}</span>`;
    els.logList.appendChild(line);
  }

  function animateCount(el, target, { suffix = '', duration = 900 } = {}) {
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      const value = Math.floor(eased * target);
      el.textContent = value.toLocaleString() + suffix;
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  async function runPhase2() {
    els.logList.innerHTML = '';
    els.spinner.style.display = '';
    document.querySelectorAll('#stat-grid .stat-card').forEach((c) => c.classList.remove('show'));
    els.statPhotos.textContent = '0';
    els.statVideos.textContent = '0';
    els.statStorage.textContent = '0%';

    for (const log of PHASE2_LOGS) {
      appendLogLine(log);
      await wait(rand(420, 620));
    }

    await wait(300);
    els.spinner.style.display = 'none';

    // Randomly generated fake values — never derived from real device data.
    const fakePhotos = randInt(2800, 6400);
    const fakeVideos = randInt(120, 480);
    const fakeStorage = randInt(38, 82);

    const cards = document.querySelectorAll('#stat-grid .stat-card');
    cards.forEach((c, i) => setTimeout(() => c.classList.add('show'), i * 120));

    animateCount(els.statPhotos, fakePhotos, { duration: 1000 });
    animateCount(els.statVideos, fakeVideos, { duration: 1000 });
    animateCount(els.statStorage, fakeStorage, { suffix: '%', duration: 1000 });

    await wait(1900);
    showPhase(els.phase3);
    runPhase3();
  }

  /* ------------------------------------------------------------------ *
   * PHASE 3 — fake archive progress
   * ------------------------------------------------------------------ */
  const FILE_PREFIXES = ['IMG', 'VID', 'Photo', 'Vacation', 'Screenshot', 'Backup', 'Memory', 'Clip'];
  const FILE_EXTS = { photo: ['jpg', 'jpeg', 'png', 'heic'], video: ['mp4', 'mov'] };

  function randomFilename() {
    const prefix = pick(FILE_PREFIXES);
    const isVideo = prefix === 'VID' || prefix === 'Clip';
    const ext = pick(isVideo ? FILE_EXTS.video : FILE_EXTS.photo);

    if (prefix === 'IMG' || prefix === 'VID') {
      const y = 2026, m = '07', d = '04';
      const seq = String(randInt(1, 999)).padStart(3, '0');
      return `${prefix}_${y}_${m}_${d}_${seq}.${ext}`;
    }
    return `${prefix}${randInt(1, 9999)}.${ext}`;
  }

  let phase3Timers = [];
  function clearPhase3Timers() {
    phase3Timers.forEach((t) => clearInterval(t) || clearTimeout(t));
    phase3Timers = [];
  }

  function runPhase3() {
    let progress = 0;
    let photosProcessed = 0;
    let videosProcessed = 0;
    let archiveSize = 0;

    const totalDurationMs = 9600; // ~10s to sweep 0 -> 100
    const stepMs = 90;
    const stepIncrement = 100 / (totalDurationMs / stepMs);

    els.progressFill.style.width = '0%';
    els.progressPercent.textContent = '0%';
    els.counterPhotos.textContent = '0';
    els.counterVideos.textContent = '0';
    els.counterSize.textContent = '0.0 MB';
    els.counterRate.textContent = '0.0 MB/s';

    // Rapidly changing filenames
    const filenameTimer = setInterval(() => {
      els.filenameCurrent.textContent = randomFilename();
    }, 100);
    phase3Timers.push(filenameTimer);

    // Progress + counters
    const progressTimer = setInterval(() => {
      progress = Math.min(100, progress + stepIncrement);
      els.progressFill.style.width = progress.toFixed(1) + '%';
      els.progressPercent.textContent = Math.floor(progress) + '%';

      photosProcessed += randInt(3, 14);
      videosProcessed += randInt(0, 2);
      archiveSize += rand(0.4, 2.1);
      const rate = rand(4.5, 22.8);

      els.counterPhotos.textContent = photosProcessed.toLocaleString();
      els.counterVideos.textContent = videosProcessed.toLocaleString();
      els.counterSize.textContent = archiveSize.toFixed(1) + ' MB';
      els.counterRate.textContent = rate.toFixed(1) + ' MB/s';

      if (progress >= 100) {
        clearInterval(progressTimer);
        clearInterval(filenameTimer);
      }
    }, stepMs);
    phase3Timers.push(progressTimer);
  }

  /* ------------------------------------------------------------------ *
   * Cancel → interrupt modal → countdown → final reveal
   * ------------------------------------------------------------------ */
  let countdownInterval = null;
  let revealTimeout = null;

  els.cancelBtn.addEventListener('click', () => {
    vibrate([15, 40, 15]);
    clearPhase3Timers(); // freeze the progress bar exactly where it is

    els.modal.classList.add('show');
    els.modal.setAttribute('aria-hidden', 'false');

    let secondsLeft = 30;
    els.countdown.textContent = secondsLeft;
    els.countdownFill.style.width = '100%';

    countdownInterval = setInterval(() => {
      secondsLeft -= 1;
      if (secondsLeft < 0) {
        clearInterval(countdownInterval);
        return;
      }
      els.countdown.textContent = secondsLeft;
      els.countdownFill.style.width = (secondsLeft / 30 * 100) + '%';
    }, 1000);

    // The simulation always resolves into the reveal after ~10s,
    // regardless of the (purely cosmetic) countdown value.
    revealTimeout = setTimeout(runFinalReveal, 10000);
  });

  async function runFinalReveal() {
    if (countdownInterval) clearInterval(countdownInterval);

    els.modal.classList.remove('show');
    els.modal.setAttribute('aria-hidden', 'true');

    els.phase3.classList.add('phase-exiting');
    await wait(400);

    if (document.fullscreenElement && document.exitFullscreen) {
      try { await document.exitFullscreen(); } catch (_) { /* ignore */ }
    }

    showPhase(els.phaseFinal);
    vibrate(20);
  }

  /* ------------------------------------------------------------------ *
   * Replay — full reset back to Phase 1
   * ------------------------------------------------------------------ */
  els.replayBtn.addEventListener('click', () => {
    clearPhase3Timers();
    if (countdownInterval) clearInterval(countdownInterval);
    if (revealTimeout) clearTimeout(revealTimeout);

    els.phase3.classList.remove('phase-exiting');
    els.phase1.classList.remove('phase-exiting');
    els.grantBtn.disabled = false;
    els.logList.innerHTML = '';

    showPhase(els.phase1);
  });

})();
